<?php
include '../config/koneksi.php';
$id = $_POST['id_aspirasi'] ?? null;


mysqli_query($koneksi, "delete from aspirasi where id_aspirasi = '$id'");
header("location:../admin/dashboard.php");
exit;
