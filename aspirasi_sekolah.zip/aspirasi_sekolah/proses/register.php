<?php
session_start();
include '../config/koneksi.php';

$nama = $_POST['user'];
$kelas = $_POST['kelas'];

$check = mysqli_query($koneksi, "SELECT * FROM siswa WHERE nama='$nama'");
if (mysqli_num_rows($check) > 0){
    echo "<script>alert('Username telah digunakan, mohon gunakan username lain');
        window.location = '../register.php';
        </script>
        ";
    exit;
}

mysqli_query($koneksi, "INSERT INTO siswa (nama, kelas)
VALUES ('$nama','$kelas')");


echo "<script>alert('Pembuatan Akun berhasil');
window.location = '../login.php';
</script>
";

exit;