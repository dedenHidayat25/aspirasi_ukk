<div id="content-wrapper" class="d-flex flex-column">
<div id="content">

<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 shadow">
  <span>Aspirasi Sekolah</span>
    <ul class="navbar-nav ml-auto">
      
        <li class="nav-item">
            <a class="btn btn-primary text-white mx-4" href="login.php">
                Login
            </a>
            <a class="btn btn-light shadow text-black mx-4" href="register.php">
                Register
            </a>
        </li>
    </ul>

</nav>
