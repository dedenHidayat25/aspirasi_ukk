<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pengaduan Sarana Sekolah</title>
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <style>
        .hero-section{
            width:100%;
            padding: 150px 200px;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f3f3f3;
        }
        .hero-section .container-hero{
            text-align: center;
            display: flex;
            flex-direction: column;
        }
        .hero-section .container-hero .container-headline{
            display: flex;
            gap: 12px;
            flex-direction: column;
            margin: auto;
            height: auto;
        }
        .hero-section .container-hero .container-headline .container-button{
            padding: 0px 200px;
        }
        .hero-section .container-hero h1{
            font-weight: 500;
            color: black;
            font-size: 60px;
        }
        .hero-section .container-hero span{
            font-weight: 500;
            color: #1677f7;
        }
        .hero-section .container-hero a{
            display: block;
        }
        .hero-section .container-hero .container-image img{
            display: block;
            margin-top: 100px;
            border-radius: 8px;
        }
    </style>
</head>
<body id="page-top">

<div id="wrapper">
