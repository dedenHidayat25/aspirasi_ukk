<?php include 'assets/template/index/header.php'?>
<?php include 'assets/template/index/navbar.php';
?>
<main>
    <section class="hero-section">
        <div class="container-hero">
            <div class="container-headline">
                 <h1>Mengirim Aspirasi Sekolah <br><span>Dengan Nyaman</span></h1>
                <p>Platform ini dirancang untuk mempermudah siswa untuk menyampaikan aspirasi secara efesien, mudah, praktis. </p>
                <div class="container-button">
                     <a href="login.php" class="btn btn-primary text-white mx-4">Mari Hubungkan!</a>
                </div>
            </div>
           
           
            <div class="container-image">
                 <img src="assets/img/dashboard-admin.png" alt="" height="900px" width="1700px">
            </div>
        </div>
</section>
</main>
<?php include 'assets/template/index/footer.php';?>