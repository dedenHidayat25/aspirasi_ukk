<?php include 'assets/template/index/header.php'; ?>

<div class="container">

    <div class="row justify-content-center mt-5">
        <div class="col-lg-5">

            <div class="card shadow">
                <div class="card-header bg-primary text-white text-center">
                    <h5 class="m-0 font-weight-bold">
                        Register Aplikasi Aspirasi Sekolah
                    </h5>
                </div>

                <div class="card-body">

                    <form action="proses/register.php" method="POST">
                        <div class="form-group">
                            <label>Username / NIS</label>
                            <input type="text" name="user" class="form-control"
                                placeholder="Buat Username" required>
                        </div>
                        <div class="form-group">
                            <label>Kelas</label>
                            <input type="kelas" name="kelas" class="form-control"
                                placeholder="Masukkan Kelas anda">
                        </div>
                        <button type="submit" class="btn btn-success btn-block">
                            <i class="fas fa-sign-in-alt"></i> Register
                        </button>
                    </form>

                </div>

            </div>

            <div class="text-center mt-3">
                <a href="index.php">← Kembali ke Beranda</a>
            </div>
            
        </div>
    </div>
</div>


<?php include 'assets/template/index/footer.php'; ?>