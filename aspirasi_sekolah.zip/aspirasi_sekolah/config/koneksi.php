<?php
$koneksi = mysqli_connect("localhost", "root", "", "aspirasi_sekolah");

if (!$koneksi){
    echo "Koneksi gagal";
}