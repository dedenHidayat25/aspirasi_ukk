# Dokumentasi Project Aplikasi Asprirasi Sekolah
---
## ERD ( Entitty Relationship Diagram )

Table Admin:
username varchar
password varchar

Table Siswa:
nis primary key, int
nama varchar
kelas varchar

Table Kategori
id_primary primary key, int
ket_kategori varchar

Table Aspirasi
id_aspirasi primary key, int
nis index, int
id_kategori index, int
lokasi varchar
keterangan varchar 
status enum
tangggal date

siswa -> [ Input ] <- Aspirasi, one to many.
id_kategori -> [ jenis_kategori ] <- aspirasi, one to many.

## Deskripsi Program

Aplikasi ini dirancang untuk mempermudah siswa untuk mengirim aspirasi lewat digital, lalu bisa di monitoring oleh tim pengurus sekolah. Masalah yang ada sekarang, ketika siswa ingin menyampaikan keluh kesah kepada pimpinan sekolah. banyak sekali kendalanya:

dimulai dari pimpinan sibuk, murid yang malu ketemu guru, tidak ada alat pemantauan, dll. nah, dengan aplikasi ini masalah tersebut dapat terselesaikan!

aplikasi ini dirancang untuk siswa dan juga pimpinan sekolah, karena dengan serba teknologi sekarang. seharusnya teknologi itu mempermudah manusia dalam bekerja!
---
### Login & Register

Aplikasi ini dilengkapi dengan fitur untuk login dan register untuk siswa, namun untuk admin. hanya bisa login saja!

### Fitur yang dimiliki oleh siswa

- Siswa dapat mengirim aspirasi, berdasarkan kategori ( kenakalan, Kerusakan, Aspirasi ). 
- Siswa dapat melihat histori / data yang telah dikirim sebelumnya! disana terdapat tanggal, keterangan, status, feedback!

### Fitur yang dimiliki admin

- Admin dapat melihat data-data aspirasi yang telah dikirim siswa.
- Admin dapat mengubah status, mulai dari ( Menunggu, Proses. Selesai ).
- Admin dapat menghapus sebuah aspirasi, lewat dashboard.
- Admin dapat Memfilter pencarian aspirasi yang berdasarkan jenis kategori, bulan, tanggal.
- Admin dapat membuat laporan / mencetak PDF dari data yang ada.

---
## Debugging

Saya telah membuat beberapa test pada aplikasi ini dan ini adalah hasil yang saya dapatkan!
---
### Login & Register 

Login dan Register berjalan mulus untuk siswa, namun untuk admin hanya bisa untuk login saja! sistem dapat mengenali data dengan baik, dan sistem membuat data dengan baik

### Input Aspirasi

Sistem dapat mengirim Aspirasi dengan hasil yang diharapkan yaitu pada tabel aspirasi, dan relasinya tidak berantakan.

### Histori & Pencetakan Data Aspirasi

Sistem menampilkan data pada dashboard admin dan siswa dengan hasil yang diharapkan!. Fitur Cetak Dokumen juga tersedia.

### Mengubah Data / Menghapus Data

Pada Dashboard admin, data dapat dirubah tanpa terkendala. data dapat diubah statusnya, dan dapat di hapus jika mengangggu.
---
## Hasil yang diharapkan
Saya merasa cukup bangga, dengan program yang saya buat pada hari UKK ini. banyak fitur yang telah saya buat, terutama untuk fitur siswa dan admin. namun...

Saya rasa, aplikasi ini belum sempurna. saya mencatat kelemahan, untuk saya pelajari kedepannya!

- Tidak Responsif, di berbagai layar device!
- Password tidak di hashing! dan memiliki resiko SQL Injection.
- Tampilan yang kurang menarik